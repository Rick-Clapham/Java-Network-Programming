/*
* Name: Richard Clapham 
* Student #: 821-490-125
* Last Modified: 9/28/2015
*
* Code initally provided by Muhammad Khan it has since been modified to incorporate a GUI
*/

import java.util.Enumeration;
import java.net.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Lab2GUI extends JFrame 
{
    private JButton myButton;
    private JTextField addressField;
    private JRadioButton iRButton, dnsRButton;
    private JTextArea  displayInformationArea;
    private ButtonGroup radioButtonGroup;
    private JLabel displayLabel;

    public Lab2GUI ( ) 
    { // constructor begins
     super("Rick Clapham - 821-490-125");
     
     setLayout (new GridLayout(4,2));

     myButton = new JButton ("Display");
     addressField = new JTextField ("Enter IP Address or DNS information");
     addressField.setEditable(false);
     displayInformationArea = new JTextArea();
     displayInformationArea.setEditable(false);
     displayLabel = new JLabel("Enter IP address or Domain Name");
     iRButton = new JRadioButton ("Interface Information");
     dnsRButton = new JRadioButton ("DNS Services");
     radioButtonGroup = new ButtonGroup();
     radioButtonGroup.add(iRButton);
     radioButtonGroup.add(dnsRButton);
     
     
     add(iRButton);
     add(dnsRButton);
     add(displayLabel);
     add(addressField);
     add(new JScrollPane(displayInformationArea));
     add(myButton);
     
     RadioButtonHandler rButtonHandler = new RadioButtonHandler();
     JButtonHandler jButtonHandler = new JButtonHandler();
     
     iRButton.addItemListener(rButtonHandler);
     dnsRButton.addItemListener(rButtonHandler);
     myButton.addActionListener(jButtonHandler);
    } // end of the constructor GraphicalUserInterface  
    
    
    // Definition of the inner class RadioButtonHandler

    private class RadioButtonHandler implements ItemListener 
    {
        public RadioButtonHandler() {} // Constructor of RadioButtonHandler 
        
        public void itemStateChanged (ItemEvent event) 
        {
            if (event.getSource() == iRButton )
            {
                addressField.setEditable(true);
                addressField.setText("Interface Radio Button Selected");
                addressField.setEditable(false);
                displayInformationArea.setEditable(false);
                displayInformationArea.setText("");
                displayInformationArea.setEditable(false);
            } // end of if condition that iRButton is selected
            else if (event.getSource() == dnsRButton) {
                addressField.setEditable(true);
                addressField.setText("DNS Radio Button is selected");
                addressField.setEditable(true);
                displayInformationArea.setEditable(true);
                displayInformationArea.setText("");
                displayInformationArea.setEditable(false);
            } // end of else if condition that dnsRButton is selected
        } // end of method itemStateChanged
    } // end of class definition RadioButtonHandler
    
    
    // Beginning of the inner class JButtonHandler


    private class JButtonHandler  implements ActionListener 
    { //beginning fo the class JButtonHandler
      public JButtonHandler (){} //CONSTRUCTOR 
      
      public void actionPerformed ( ActionEvent event) 
      { // beginning of actionPerformed
          if (iRButton.isSelected() ) 
          { //beginning of method if iRButton selected
             displayInformationArea.setEditable(true);
             addressField.setEditable(true);
             displayInformationArea.setText("Interface Radio Button selected:  " + addressField.getText() + "\n");
             
              /*
              *This is the inputted code taken from Muhammad Khan's InetAClass.java
              *This is the interface services 
              */
                           
             try 
             {
               Enumeration<NetworkInterface> interfaceList = NetworkInterface.getNetworkInterfaces();
               if (interfaceList == null) 
               {
                  displayInformationArea.append("--NO Interfaces found -- ");
               }
               else 
               {
                  while (interfaceList.hasMoreElements() ) 
                  {
				         NetworkInterface iface = interfaceList.nextElement();
				         displayInformationArea.append("Interface " + iface.getName() + ":\n");
                     displayInformationArea.append("Interface " + iface.getName() + " is Up - " + iface.isUp() + "\n");
                     displayInformationArea.append("Interface " + iface.getName() + " is Virtual - " + iface.isVirtual() + "\n");
                     Enumeration<InetAddress> addrList = iface.getInetAddresses();
                     if (!addrList.hasMoreElements()) 
                     {
                        displayInformationArea.append("\t --No Addresses for this interface...---\n");
                     } // if
                     while (addrList.hasMoreElements()) 
                     {
                        InetAddress address = addrList.nextElement();
                        displayInformationArea.append("\t Address " + (( address instanceof Inet4Address ? "(v4)"
                                         : (address instanceof Inet6Address ? "(v6)" : "(?)" ))));
                        displayInformationArea.append(" : " + address.getHostAddress() + "\n");
                     } //while
                  } // while
               } // else
            } // try ends
            catch (SocketException se) 
            {
               displayInformationArea.setText("Error getting network interfaces: " + se.getMessage());
            } 
            
          addressField.setEditable(false);
          displayInformationArea.setEditable(false);
          } // if iRButton is selected
          else if (dnsRButton.isSelected()) 
          {
              displayInformationArea.setEditable(true);
              addressField.setEditable(true);
              displayInformationArea.setText("DNS Button Selected:  " + addressField.getText());
              
              
              /*
              *This is the inputted code taken from Muhammad Khan's InetAClass.java
              *This is the DNS services
              */
              
              String host = addressField.getText(); 
              try 
              { // try begins
                displayInformationArea.append("\n");
                displayInformationArea.append("My Arguments will be Displayed Below\n");
                displayInformationArea.append(host + ":" );
                InetAddress [] addressList = InetAddress.getAllByName(host);
                for (InetAddress address : addressList ) 
                {
                  displayInformationArea.append("\t" + address.getHostName() + "/" + address.getHostAddress() + "\n");
                } //for
              } // end of try
              catch (UnknownHostException e) 
              {
                 displayInformationArea.append("\n Unable to find address for " + host + "\n");
              } // end of catch
              
            addressField.setEditable(false);
            displayInformationArea.setEditable(false);
          } // end of the method if dnsRButton is selected
          else  
          {
            displayInformationArea.setEditable(true);
            addressField.setEditable(true);
            displayInformationArea.setText("None of the Radio Buttons are selected");
            displayInformationArea.setEditable(false);
            addressField.setEditable(false);
            displayInformationArea.setEditable(false);
          } // end of else - if iRButton is NOT selected and dnsRButton is NOT selected
       } //end of the method actionPerformed
    } // end of the class JButtonHandler
    
    public static void main (String [] args) 
    {
        Lab2GUI myGUIApp = new Lab2GUI();
        myGUIApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myGUIApp.setSize(1000,600);
        myGUIApp.setVisible(true);
    }
 }