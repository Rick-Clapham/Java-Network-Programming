/*
* Name: Richard Clapham 
* Student #: 821-490-125
* Last Modified: 9/28/2015
*
* Code initally provided by Muhammad Khan it has since been modified to incorporate a GUI
*/

import java.io.*;
import java.net.*;
import java.util.Enumeration;

import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Lab3GUI extends JFrame 
{
    private JButton myButton;
    private JTextField ipField;
    private JTextField pNumField;
    private JRadioButton iRButton, pNumRButton;
    private JTextArea  displayInformationArea;
    private ButtonGroup radioButtonGroup;
    private JLabel displayLabel1;
    private JLabel displayLabel2;

    public Lab3GUI ( ) 
    { // constructor begins
     super("Rick Clapham - 821-490-125");
     
     setLayout (new GridLayout(4,2));

     myButton = new JButton ("Remote Host Information");
     ipField = new JTextField ("Enter IP address");
     ipField.setEditable(false);
     pNumField = new JTextField ("Enter port Number address");
     pNumField.setEditable(false);
     displayInformationArea = new JTextArea();
     displayInformationArea.setEditable(false);
     displayLabel1 = new JLabel("Enter IP Address");
     displayLabel2 = new JLabel("Enter Port Number");
     iRButton = new JRadioButton ("Interface Information");
     pNumRButton = new JRadioButton ("Fully Qualified Domain Name");
     radioButtonGroup = new ButtonGroup();
     radioButtonGroup.add(iRButton);
     radioButtonGroup.add(pNumRButton);
     
     add(iRButton);
     add(pNumRButton);
     add(displayLabel1);
     add(ipField);
     add(displayLabel2);
     add(pNumField);
     add(new JScrollPane(displayInformationArea));
     add(myButton);
     
     ipField.setEditable(true);
     pNumField.setEditable(true);
     
     RadioButtonHandler rButtonHandler = new RadioButtonHandler();
     JButtonHandler jButtonHandler = new JButtonHandler();
     
     iRButton.addItemListener(rButtonHandler);
     pNumRButton.addItemListener(rButtonHandler);
     myButton.addActionListener(jButtonHandler);
    } // end of the constructor GraphicalUserInterface  
    
    
    // Definition of the inner class RadioButtonHandler

    private class RadioButtonHandler implements ItemListener 
    {
        public RadioButtonHandler() {} // Constructor of RadioButtonHandler 
        
        public void itemStateChanged (ItemEvent event) 
        {
            if (event.getSource() == iRButton )
            {
                ipField.setEditable(false);
                displayInformationArea.setEditable(true);
                displayInformationArea.setText("");
                displayInformationArea.setEditable(false);
            } // end of if condition that iRButton is selected
            else if (event.getSource() == pNumRButton) 
            {
                ipField.setEditable(true);
                displayInformationArea.setEditable(true);
                displayInformationArea.setText("");
                displayInformationArea.setEditable(false);
            } // end of else if condition that pNumRButton is selected
        } // end of method itemStateChanged
    } // end of class definition RadioButtonHandler
    
    
    // Beginning of the inner class JButtonHandler


    private class JButtonHandler  implements ActionListener 
    { //beginning fo the class JButtonHandler
      public JButtonHandler (){} //CONSTRUCTOR 
      
      public void actionPerformed ( ActionEvent event) 
      { // beginning of actionPerformed
         String myIP = ipField.getText();
         String myPNum = pNumField.getText();
         int pNum = Integer.parseInt(myPNum);
         
          if (iRButton.isSelected() ) 
          { //beginning of method if iRButton selected 
             displayInformationArea.setEditable(true);
             
             String host = "localhost";
             DatagramSocket s = null;
             try
             {
               s = new DatagramSocket ();
               byte [] buffer = new String("interface").getBytes ();
               InetAddress ia = InetAddress.getByName (host);
               //InetAddress ia2 = InetAddress.getByAddress("142.214.223.31".getBytes());
               DatagramPacket dgp = new DatagramPacket(buffer, buffer.length,ia,pNum);
               s.send (dgp);
               
               byte [] buffer2 = new byte [2000];
               DatagramPacket dgp2 = new DatagramPacket (buffer2,buffer2.length);
               s.receive(dgp2);
               
               displayInformationArea.setText(new String(dgp2.getData()));
             }
             catch (IOException e)
             {
               System.out.println (e.toString ());
             }
             finally
             {
               if (s != null)
                  s.close ();
             }
             
             displayInformationArea.setEditable(false);
          } // if iRButton is selected
          else if (pNumRButton.isSelected())
          {
             displayInformationArea.setEditable(true);
              
             String host = "localhost";
             DatagramSocket s = null;
             try
             {
               s = new DatagramSocket ();
               byte [] buffer = new String(myIP).getBytes ();
               InetAddress ia = InetAddress.getByName(host);
               InetAddress ia2 = InetAddress.getByAddress("142.214.223.5".trim().getBytes());
               DatagramPacket dgp = new DatagramPacket(buffer, buffer.length,ia2,pNum);
               s.send (dgp);
               
               byte [] buffer2 = new byte [2000];
               DatagramPacket dgp2 = new DatagramPacket (buffer2,buffer2.length);
               s.receive(dgp2);
               
               displayInformationArea.setText(new String(dgp2.getData()));
             }
             catch (IOException e)
             {
               System.out.println (e.toString ());
             }
             finally
             {
               if (s != null)
                  s.close ();
             }
             
             displayInformationArea.setEditable(false);
          } // end of the method if pNumRButton is selected
          else  
          {
            displayInformationArea.setEditable(true);
            displayInformationArea.setText("None of the Radio Buttons are selected");
            displayInformationArea.setEditable(false);
          } // end of else - if iRButton is NOT selected and pNumRButton is NOT selected
       } //end of the method actionPerformed
    } // end of the class JButtonHandler
    
    public static void main (String [] args) 
    {
        Lab3GUI myGUIApp = new Lab3GUI();
        myGUIApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myGUIApp.setSize(1000,600);
        myGUIApp.setVisible(true);
    }
 }