/*
* Name: Richard Clapham 
* Student #: 821-490-125
* Last Modified: 9/28/2015
*
* Code initally provided by Muhammad Khan it has since been modified to incorporate a GUI
*/

// Lab2Server.java
// This Server application is taken from an article published by Quepublishing

import java.io.*;
import java.net.*;
import java.util.Enumeration;

class Lab3Server
{

   public static void main (String [] args) throws IOException
   {
      System.out.println ("Server starting ...\n");
      DatagramSocket s = new DatagramSocket (40050);
      byte [] data = new byte [2000];
      DatagramPacket dgp = new DatagramPacket (data, data.length);
      

      // Enter an infinite loop. Press Ctrl+C to terminate program.
      while (true)
      {
         s.receive (dgp);
         System.out.println (new String (data));     
         String request = (new String(dgp.getData())).trim();      
         StringBuffer sBuffer = new StringBuffer();        
         
         if(request.equals("interface"))
         {          
            try 
             {
               Enumeration<NetworkInterface> interfaceList = NetworkInterface.getNetworkInterfaces();
               if (interfaceList == null) 
               {
                 sBuffer.append("--NO Interfaces found -- \n");
               }
               else 
               {
                  while (interfaceList.hasMoreElements() ) 
                  {
				         NetworkInterface iface = interfaceList.nextElement();
				         sBuffer.append("Interface " + iface.getName() + ":\n");
               
                     Enumeration<InetAddress> addrList = iface.getInetAddresses();
                     if (!addrList.hasMoreElements()) 
                     {
                        sBuffer.append("\t --No Addresses for this interface...---\n");
                     } // if
                     while (addrList.hasMoreElements()) 
                     {
                        InetAddress address = addrList.nextElement();
                        sBuffer.append("\t Address " + (( address instanceof Inet4Address ? "(v4)" : (address instanceof Inet6Address ? "(v6)" : "(?)" ))));
                        sBuffer.append(" : " + address.getHostAddress() + "\n");
                     } //while
                  } // while
               } // else
            } // try ends
            catch (SocketException se) 
            {
              sBuffer.append("Error getting network interfaces: " + se.getMessage() + "\n");
            } 
            // Echo datagram packet back to client program.
            String myString = sBuffer.toString();
            byte[] buffer2 = myString.getBytes();
         
            DatagramPacket dgp2 = new DatagramPacket(buffer2,buffer2.length, dgp.getSocketAddress());
            s.send(dgp2);
         }
         else
         {
            String host = request; 
            try 
            { // try begins
              sBuffer.append("\n");
              sBuffer.append("My Arguments will be Displayed Below\n");
              sBuffer.append(host + ":" );
              InetAddress [] addressList = InetAddress.getAllByName(host);
              for (InetAddress address : addressList ) 
              {
                sBuffer.append("\t" + address.getHostName() + "/" + address.getHostAddress() + "\n");
              } //for
            } // end of try
            catch (UnknownHostException e) 
            {
               sBuffer.append("\n Unable to find address for " + host + "\n");
            } // end of catch
            
            String myString = sBuffer.toString();
            byte[] buffer2 = myString.getBytes();
         
            DatagramPacket dgp2 = new DatagramPacket(buffer2,buffer2.length, dgp.getSocketAddress());
            s.send(dgp2);
         }
      }
   }
} // end of the class File_Server