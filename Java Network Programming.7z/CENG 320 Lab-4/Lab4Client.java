/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/11/2015
*
* Prompts the user to select a file the program will then recieve
* an ipaddress / domain name and a port number and will then send the seleced
* text file to the destination

* Sorry if the javadocs aren't working correctly however the code does work
* with the exception that if the file is to large it will get an ArrayIndexOutOfBoundsException
* as well the program only writes the file to another hard coded filename (myFile.txt.bak)
*****/

import java.io.*;
import java.net.*;
import java.util.Enumeration;

import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.*;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.*;

import java.nio.file.*;

public class Lab4Client extends JFrame
{
    static private final String newline = "\n";
    private JButton myButton;
    private JTextField ipField;
    private JTextField pNumField;
    private JRadioButton sFRButton, nARButton;
    private JTextArea  displayInformationArea;
    private ButtonGroup radioButtonGroup;
    private JLabel displayLabel1;
    private JLabel displayLabel2;
    
    private File myFile;
    private String myFileName;
    private Path myPath;
    private byte[] sentByteBuffer = new byte[1000];
    private byte[] receivedByteBuffer = new byte[1000];
    byte[] data;
    
    public Lab4Client ( ) 
    { // constructor begins
     super("Rick Clapham - 821-490-125");
     
     setLayout (new GridLayout(4,2));

     myButton = new JButton ("Create Backup");
     ipField = new JTextField ("Enter IP address");
     ipField.setEditable(false);
     pNumField = new JTextField ("Enter port Number address");
     pNumField.setEditable(false);
     displayInformationArea = new JTextArea();
     displayInformationArea.setEditable(false);
     displayLabel1 = new JLabel("Enter IP Address:");
     displayLabel2 = new JLabel("Enter Port Number:");
     sFRButton = new JRadioButton ("Save File");
     nARButton = new JRadioButton ("N/A");
     radioButtonGroup = new ButtonGroup();
     radioButtonGroup.add(sFRButton);
     radioButtonGroup.add(nARButton);
     
     add(sFRButton);
     add(nARButton);
     add(displayLabel1);
     add(ipField);
     add(displayLabel2);
     add(pNumField);
     add(new JScrollPane(displayInformationArea));
     add(myButton);
     
     ipField.setEditable(true);
     pNumField.setEditable(true);
     
     RadioButtonHandler rButtonHandler = new RadioButtonHandler();
     JButtonHandler jButtonHandler = new JButtonHandler();
     
     sFRButton.addItemListener(rButtonHandler);
     myButton.addActionListener(jButtonHandler);
    } // end of the constructor GraphicalUserInterface  
        
    // Definition of the inner class RadioButtonHandler
    private class RadioButtonHandler implements ItemListener 
    {
        public RadioButtonHandler() {} // Constructor of RadioButtonHandler 
        
        public void itemStateChanged (ItemEvent event) 
        {
            if (event.getSource() == sFRButton )
            {
                ipField.setEditable(true);
                displayInformationArea.setEditable(true);
          
                chooseFile(); //Launches the fileChooser method

                displayInformationArea.setEditable(false);
            } 
            else if (event.getSource() == nARButton) 
            {
                ipField.setEditable(true);
                displayInformationArea.setEditable(true);
                displayInformationArea.setText("");
                displayInformationArea.setEditable(false);
            }// end of if condition that sFRButton is selected
        } // end of method itemStateChanged
    } // end of class definition RadioButtonHandler
    
    // Beginning of the inner class JButtonHandler
    private class JButtonHandler  implements ActionListener 
    { //beginning fo the class JButtonHandler
      public JButtonHandler (){} //CONSTRUCTOR 
      
      public void actionPerformed ( ActionEvent event) 
      { // beginning of actionPerformed

          if (sFRButton.isSelected() ) 
          { //beginning of method if sFRButton selected 
             displayInformationArea.setEditable(true);
             
             toServer(); //Launches the toServer method
             
             displayInformationArea.setEditable(false);
          } // if sFRButton is selected
          else if (nARButton.isSelected())
          {
             displayInformationArea.setEditable(true);
             
             displayInformationArea.setEditable(false);
          } // end of the method if nARButton is selected
          else  
          {
            displayInformationArea.setEditable(true);
            displayInformationArea.setText("None of the Radio Buttons are selected");
            displayInformationArea.setEditable(false);
          } // end of else - if sFRButton is NOT selected and nARButton is NOT selected
       } //end of the method actionPerformed
    } // end of the class JButtonHandler
      
       
    /***
    * This is the code thast will open the fileChooser and allow
    * the user to select a file and it will store the path             
    */   
    public void chooseFile()
    {
      JFileChooser fileChooser = new JFileChooser();
      int returnValue = fileChooser.showOpenDialog(null);
      if (returnValue == JFileChooser.APPROVE_OPTION) 
      {
        File selectedFile = fileChooser.getSelectedFile();
        myFile = fileChooser.getSelectedFile();
        myFileName = selectedFile.getName();
        myPath = Paths.get(fileChooser.getSelectedFile().getAbsolutePath());
        displayInformationArea.setText("File Name: " + myFileName + "\nFile Path: " + myPath);
                        
        try
        {
           FileInputStream inputStream = new FileInputStream(myPath.toString());
           ByteArrayOutputStream baos = new ByteArrayOutputStream();
           int receivedMessageSize = 0;
               
           while(true) 
           {
            receivedMessageSize = inputStream.read(sentByteBuffer);
            if( receivedMessageSize < 0 ) break;
            baos.write(sentByteBuffer,0,receivedMessageSize);
           }
           
           data = baos.toByteArray();
                 
           baos.close();
           inputStream.close();
         }
         catch(FileNotFoundException ex) {displayInformationArea.setText("Unable to open file '" + myFileName + "'");}
         catch(IOException ex) {displayInformationArea.setText("Error reading file '" + myFileName + "'");} 
      }
    } 
    
    /*
    *This is the beginning of my method that will send inofrmation to the server
    *
    */
    
    public void toServer()
    {
      String serverInfoName = ipField.getText();
      String myPNum = pNumField.getText();
      int serverPort = Integer.parseInt(myPNum);
      String messageSent="";
      String messageReceived="";
             
      try
      {
        Socket socket = new Socket (serverInfoName, serverPort);
        InputStream  in = socket.getInputStream();
        OutputStream out = socket.getOutputStream ();
        byte[] buffer = data;
        out.write(buffer);
               
        int totalBytesReceived = 0; // this is count of the total received bytes
        int bytesReceived = 0; // bytes received in the last receive method 
               
        while ( totalBytesReceived < buffer.length) 
        { // while begins
          if ((bytesReceived = in.read(receivedByteBuffer, totalBytesReceived, buffer.length - totalBytesReceived)) == -1 )
            throw new SocketException ("Connection closed prematurely...........\n");
            totalBytesReceived += bytesReceived;
        } // while loop ends here - comparing the totalBytesReceived with bytes sent out
   
        // Now display Bytes that are received back
        displayInformationArea.setText("The message from the server is recieved:\n\n" + new String (receivedByteBuffer) );
        socket.close();
               
      }
      catch(IOException e){displayInformationArea.setText("Error Sending data to server");}
    } 
       
    public static void main (String [] args) 
    {
        Lab4Client myGUIApp = new Lab4Client();
        myGUIApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myGUIApp.setSize(1000,600);
        myGUIApp.setVisible(true);
    }
 }