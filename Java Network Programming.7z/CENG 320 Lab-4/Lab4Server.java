/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/11/2015
*
* Recieves the text file sent by the client and stores it into a .bak file
* The .bak file doesnt does not recieve and use the name of the file currently

* Sorry if the javadocs aren't working correctly however the code does work
* with the exception that if the file is to large it will get an ArrayIndexOutOfBoundsException
* as well the program only writes the file to another hard coded filename (myFile.txt.bak)
*****/


import java.io.*;
import java.net.*;
import java.util.Enumeration;

public class Lab4Server
{ // beginning of the class Lab4Server 
   private static final int BUFFERSIZE = 32;
   
   public static void main (String [] args ) throws IOException 
   {
      // main application begins here
      int serverListenPort ;  // define the integer port number
      BufferedReader inValue = new BufferedReader(new InputStreamReader(System.in));
      int receivedMessageSize=0; // size of the received message from Client
      byte[] byteBuffer = new byte[BUFFERSIZE]; // create byte buffer

      System.out.println("\nEnter the port number to listen to:\t");
      serverListenPort = Integer.parseInt(inValue.readLine());
      
      ServerSocket serverSocket = new ServerSocket(serverListenPort);

      for ( ; ; ) 
      { // Run forever - accepting and servicing connection
         Socket clientSock  = serverSocket.accept();  // Get the client connection
                   
         // Now that we have the Client connection accepted, 
         // Display client socket information
         System.out.println("\n....Handling Client at:....");
         System.out.println( clientSock.getInetAddress().getHostAddress() + "\n  on port number:\t" + clientSock.getPort());
         
         // Create an instance of InputStream from instance of Client Socket
         InputStream in = clientSock.getInputStream();
         // Create an instance of OutputStream from instance of Client Socket
         OutputStream out = clientSock.getOutputStream();
         
         int totalBytesReceived = 0; 
         int bytesReceived = 0;
         
         File file = new File("./myFile.txt.bak");        
         if (!file.exists()) {file.createNewFile();}
         FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);        
         
         while ((receivedMessageSize = in.read(byteBuffer)) != -1)
         {
           out.write(byteBuffer, 0, receivedMessageSize);
           bw.write(new String(byteBuffer));
         }
			
         bw.close();
         fw.close();
         clientSock.close(); // end of this client's echoed message
      } // end of the for loop
                  /******* this part can only be reached with Ctrl C ******/
   } // main application ends here
} // Lab4Server