/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 11/3/2015
*
* Prompts the user to select a file the program will then recieve
* an ipaddress / domain name and a port number and will then send the selected
* file to the destination by either UDP or TCP

* There is currently no errors on he cient end that i am aware of.
* There should be methods and documentation to easily read the program
* if there are any issues please notify me thank you 
*****/

import java.io.*;
import java.net.*;
import java.util.Enumeration;

import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.*;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.*;

import java.nio.file.*;

public class Lab5Client extends JFrame
{
    private JButton myButton;
    private JTextField ipField, pNumField;
    private JRadioButton UDPButton, TCPButton;
    private JTextArea  displayInformationArea;
    private ButtonGroup radioButtonGroup;
    private JLabel displayLabel1, displayLabel2;
    
    private File myFile;
    private String myFileName;
    private Path myPath;
    
    private byte[] sentByteBuffer = new byte[1000];
    private byte[] receivedByteBuffer = new byte[1000];
    byte[] data;
    
    DatagramSocket s; 
    
    public Lab5Client ( ) 
    { // constructor begins
     super("Rick Clapham - 821-490-125");
     
     setLayout (new GridLayout(4,2));

     myButton = new JButton ("Create Backup");
     ipField = new JTextField ("localhost");
     ipField.setEditable(false);
     pNumField = new JTextField ("40050");
     pNumField.setEditable(false);
     displayInformationArea = new JTextArea();
     displayInformationArea.setEditable(false);
     displayLabel1 = new JLabel("Enter IP Address:");
     displayLabel2 = new JLabel("Enter Port Number:");
     UDPButton = new JRadioButton ("UDP");
     TCPButton = new JRadioButton ("TCP");
     radioButtonGroup = new ButtonGroup();
     radioButtonGroup.add(UDPButton);
     radioButtonGroup.add(TCPButton);
     
     add(UDPButton);
     add(TCPButton);
     add(displayLabel1);
     add(ipField);
     add(displayLabel2);
     add(pNumField);
     add(new JScrollPane(displayInformationArea));
     add(myButton);
     
     ipField.setEditable(true);
     pNumField.setEditable(true);
     
     RadioButtonHandler rButtonHandler = new RadioButtonHandler();
     JButtonHandler jButtonHandler = new JButtonHandler();
     
     UDPButton.addItemListener(rButtonHandler);
     TCPButton.addItemListener(rButtonHandler);
     myButton.addActionListener(jButtonHandler);
    } // end of the constructor GraphicalUserInterface  
        
    // Definition of the inner class RadioButtonHandler
    private class RadioButtonHandler implements ItemListener 
    {
        public RadioButtonHandler() {} // Constructor of RadioButtonHandler 
        
        public void itemStateChanged (ItemEvent event) 
        {
            if (event.getSource() == UDPButton )
            {
                ipField.setEditable(true);
                displayInformationArea.setEditable(true);  
                chooseFile();       
                displayInformationArea.setEditable(false);
            } 
            else if (event.getSource() == TCPButton) 
            {
                ipField.setEditable(true);
                displayInformationArea.setEditable(true);
                chooseFile();
                displayInformationArea.setEditable(false);
            }// end of if condition that UDPButton is selected
        } // end of method itemStateChanged
    } // end of class definition RadioButtonHandler
    
    // Beginning of the inner class JButtonHandler
    private class JButtonHandler  implements ActionListener 
    { //beginning fo the class JButtonHandler
      public JButtonHandler (){} //CONSTRUCTOR 
      
      public void actionPerformed ( ActionEvent event) 
      { // beginning of actionPerformed

          if (UDPButton.isSelected() ) 
          { //beginning of method if UDPButton selected 
             displayInformationArea.setEditable(true);
             toServerUDP();
             displayInformationArea.setEditable(false);
          } // if UDPButton is selected
          else if (TCPButton.isSelected())
          {
             displayInformationArea.setEditable(true);
             toServerTCP();
             displayInformationArea.setEditable(false);
          } // end of the method if TCPButton is selected
          else  
          {
            displayInformationArea.setEditable(true);
            displayInformationArea.setText("None of the Radio Buttons are selected");
            displayInformationArea.setEditable(false);
          } // end of else - if UDPButton is NOT selected and TCPButton is NOT selected
       } //end of the method actionPerformed
    } // end of the class JButtonHandler
      
       
    /***
    * This is the code thst will open the fileChooser and allow
    * the user to select a file and it will store the path  
    * and the data inside a byte array           
    */   
    public void chooseFile()
    {
      JFileChooser fileChooser = new JFileChooser();
      int returnValue = fileChooser.showOpenDialog(null);
      if (returnValue == JFileChooser.APPROVE_OPTION) 
      {
        myFileName = fileChooser.getSelectedFile().getName();
        myPath = Paths.get(fileChooser.getSelectedFile().getAbsolutePath());
        displayInformationArea.setText("File Name: " + myFileName + "\nFile Path: " + myPath);
                        
        try
        {
           FileInputStream inputStream = new FileInputStream(myPath.toString());
           ByteArrayOutputStream baos = new ByteArrayOutputStream();
           int receivedMessageSize = 0;
               
           //while( receivedMessageSize = in.read(sentByteBuffer)) != -1)    
           //baos.write(sentByteBuffer,0,receivedMessageSize);
               
           while(true) {
            receivedMessageSize = inputStream.read(sentByteBuffer);
            if( receivedMessageSize < 0 ) break;
            baos.write(sentByteBuffer,0,receivedMessageSize);
           }
           
           data = baos.toByteArray();                 
           baos.close();
           inputStream.close();
         }
         catch(FileNotFoundException ex) {displayInformationArea.setText("Unable to open file '" + myFileName + "'");}
         catch(IOException ex) {displayInformationArea.setText("Error reading file '" + myFileName + "'");} 
      }
    } 
    
    /*
    * This is the function that is called when the user wants to send there
    * data to the UDP server. It will take the data stored from the filechooser
    * method and send it to he server. It will also concat he fileName at the
    * start of the data
    */
    
    public void toServerUDP()
    {
       String serverInfoName = ipField.getText();
       String myPNum = pNumField.getText();
       int serverPort = Integer.parseInt(myPNum);
       
       try
       {
          byte[] fileName=(((myFileName.substring(myFileName.lastIndexOf("\\")+1)).concat(":")).getBytes());
          byte[] buffer = new byte[fileName.length + data.length];
          System.arraycopy(fileName, 0, buffer, 0, fileName.length);
          System.arraycopy(data, 0, buffer, fileName.length, data.length);
          
          s = new DatagramSocket ();
          InetAddress ia = InetAddress.getByName(serverInfoName);
          DatagramPacket dgp = new DatagramPacket(buffer, buffer.length,ia,serverPort);
          s.send (dgp);
               
          byte [] buffer2 = new byte [1000];
          dgp = new DatagramPacket (buffer2,buffer2.length);
          s.receive(dgp);
               
          displayInformationArea.setText(new String(dgp.getData()).trim());
        }
        catch (IOException e){System.out.println (e.toString ());}
        finally{if (s != null)s.close ();}
    }
    
     /*
    * This is the function that is called when the user wants to send there
    * data to the TCP server. It will take the data stored from the filechooser
    * method and send it to he server. It will also concat he fileName at the
    * start of the data
    */
    
    public void toServerTCP()
    {
      String serverInfoName = ipField.getText();
      String myPNum = pNumField.getText();
      int serverPort = Integer.parseInt(myPNum);
             
      try
      {
        Socket socket = new Socket (serverInfoName, serverPort);
        InputStream  in = socket.getInputStream();
        OutputStream out = socket.getOutputStream ();
        byte[] fileName=(((myFileName.substring(myFileName.lastIndexOf("\\")+1)).concat(":")).getBytes());
        byte[] buffer = new byte[fileName.length + data.length];
        System.arraycopy(fileName, 0, buffer, 0, fileName.length);
        System.arraycopy(data, 0, buffer, fileName.length, data.length);
        
        out.write(buffer);
               
        int totalBytesReceived = 0; // this is count of the total received bytes
        int bytesReceived = 0; // bytes received in the last receive method 
               
        while ( totalBytesReceived < buffer.length) 
        { // while begins
          if ((bytesReceived = in.read(receivedByteBuffer, totalBytesReceived, buffer.length - totalBytesReceived)) == -1 )
            throw new SocketException ("Connection closed prematurely...........\n");
            totalBytesReceived += bytesReceived;
        } // while loop ends here - comparing the totalBytesReceived with bytes sent out
   
        // Now display Bytes that are received back
        displayInformationArea.setText("The message from the server is recieved:\n\n" + new String(receivedByteBuffer).trim());
        socket.close();
               
      }
      catch(IOException e){displayInformationArea.setText("Error Sending data to server");}
    } 
       
    public static void main (String [] args) 
    {
        Lab5Client myGUIApp = new Lab5Client();
        myGUIApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myGUIApp.setSize(1000,600);
        myGUIApp.setVisible(true);
    }
 }