/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 11/3/2015
*
* Recieves the file sent by the client and stores it into a .bak file

* The .bak file does not recieve and use the name of the file correctly
*****/


import java.io.*;
import java.net.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class Lab5ServerTCP
{ // beginning of the class Lab4Server 
   private static final int BUFFERSIZE = 32;
   
   public static void main (String [] args ) throws IOException 
   {
      // main application begins here
      System.out.println ("\nTCP Server starting ...\n");
      int serverListenPort = 40050;  // define the integer port number
      int receivedMessageSize=0; // size of the received message from Client
      byte [] byteBuffer = new byte [BUFFERSIZE]; 
      
      ServerSocket serverSocket = new ServerSocket(serverListenPort);

      for ( ; ; ) 
      { // Run forever - accepting and servicing connection
         Socket clientSock  = serverSocket.accept();  // Get the client connection                  
         System.out.println("\n....Handling Client at:....");
         System.out.println( clientSock.getInetAddress().getHostAddress() + "\n  on port number:\t" + clientSock.getPort());
         
         InputStream in = clientSock.getInputStream();
         OutputStream out = clientSock.getOutputStream();
         
         int totalBytesReceived = 0; 
         int bytesReceived = 0;
         
         //Recieves data ad storest into a ByteArrayOutputStream and is then stored in data
         
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         
         while (( receivedMessageSize = in.read(byteBuffer)) != -1){
                out.write(byteBuffer, 0, receivedMessageSize);
                baos.write(byteBuffer, 0, receivedMessageSize);
         }
         
         byte[] data = baos.toByteArray();
         baos.close();
         
         //String fileName = (data.toString().substring(0,data.toString().indexOf(":"))).concat(".bak");     

         //Data revieved is then stored in file

         File file = new File("./myFileTCP.txt.bak");        
         if (!file.exists()) {file.createNewFile();}
         FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);     
         bw.write(new String(data));
         bw.close();
         fw.close();
         clientSock.close(); 
      } // end of the for loop
   /******* this part can only be reached with Ctrl C ******/
   } // main application ends here
} // Lab4Server