/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 11/3/2015
*
* Recieves the file sent by the client and stores it into a .bak file

* The .bak file does not recieve and use the name of the file correctly
*****/
import java.io.*;
import java.net.*;

class Lab5ServerUDP
{
   public static void main (String [] args) throws IOException
   {
      System.out.println ("\nUDP Server starting ...\n");
      DatagramSocket s = new DatagramSocket (40050);
      byte [] data = new byte [1000];
      DatagramPacket dgp = new DatagramPacket (data, data.length);

      while (true)
      {
         s.receive (dgp); 
         System.out.println (new String (data).trim());
         s.send (dgp);
         
         //String fileName = (data.toString().substring(0,data.toString().indexOf(":"))).concat(".bak");
         
         File file = new File("./myFileUDP.txt.bak");        
         if (!file.exists()) {file.createNewFile();}
         FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);     
         bw.write(new String(data).trim());
         bw.close();
         fw.close();
      }
   }
}