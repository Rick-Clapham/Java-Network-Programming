/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/11/2015
*
* This is my Client class in which it will connect to my
* Server if the it is iniated. If a connection is established 
* you will be able to send messages between the Client and Server
*****/

import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.*;
import java.nio.file.*;

public class Client 
{
   /**
   Main method of my client class which will recieve a port and a IP address
   and connect to the Server class if it's online
   @param myIP recieves an IP adress or domain name from the user
   @param myPort recieves a port number from the user
   */
	public static void main(String myIP, int myPort)
   {
		try 
      {
			Socket mySocket = new Socket(myIP,myPort);
			ClientSendToServer mySender = new ClientSendToServer(mySocket);
			Thread myThread1 = new Thread(mySender);
         myThread1.start();
			ClientRecieveFromServer myReciever = new ClientRecieveFromServer(mySocket);
			Thread myThread2 =new Thread(myReciever);
         myThread2.start();
		} 
      catch (Exception e) {System.out.println(e.getMessage());} 
	}
}

/**
Allows the client to recieve information from the server
@param sock recieves socket information from the main 
*/
class ClientRecieveFromServer implements Runnable
{
	Socket mySocket=null;
	BufferedReader myReciever=null;
	
	public ClientRecieveFromServer(Socket sock) 
   {
		this.mySocket = sock;
	}//end constructor
   
	public void run() 
   {
		try
      {
		   myReciever = new BufferedReader(new InputStreamReader(this.mySocket.getInputStream()));//get inputstream
		   String myMessage = null;
		   while((myMessage = myReciever.readLine())!= null)
		   {
			   System.out.println("Message From Server: " + myMessage);
			   System.out.println("Please Enter A Response To The Server: ");
		   }
		}catch(Exception e){System.out.println(e.getMessage());}
	}//end run
}

/**
Allows the client to send information to the server
@param sock recieves socket information from the main 
*/
class ClientSendToServer implements Runnable
{
	Socket mySocket=null;
	PrintWriter myPrintWriter=null;
	BufferedReader myBufferedReader=null;
	
	public ClientSendToServer(Socket sock)
	{
		this.mySocket = sock;
	}//end constructor
   
	public void run()
   {
		try
      {
		   if(mySocket.isConnected())
		   {
			   System.out.println("Client Connected To:\nIP:\t"+mySocket.getInetAddress() + "\nPort:\t"+mySocket.getPort());
			   this.myPrintWriter = new PrintWriter(mySocket.getOutputStream(), true);	
		      while(true)
            {
			      System.out.println("Enter Message To Server('EXIT' To Exit):");
			      myBufferedReader = new BufferedReader(new InputStreamReader(System.in));
			      String myMessage=null;
			      myMessage = myBufferedReader.readLine();
			      this.myPrintWriter.println(myMessage);
			      this.myPrintWriter.flush();
		
			      if(myMessage.equals("EXIT"))
			         break;
			   }//end while
		      mySocket.close();
         }
      }catch(Exception e){System.out.println(e.getMessage());}
	}
}//e