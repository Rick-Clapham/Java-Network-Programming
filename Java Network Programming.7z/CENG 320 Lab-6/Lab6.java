/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/11/2015
*
* Essentially the GUI element of the program it calls
* my other classes in orderto be able to initiate aserver client chat
* 
* However inside the GUI there are 5 methods 
* 1. is to choose a file
* 2. One sends thefile to the file server
* 3. Is the File Server
* 4. Connect method which records IP and port num
* 5. Disconnect which makes IP and port num null
*****/

import java.io.*;
import java.net.*;
import java.util.Enumeration;

import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.*;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.*;

import java.nio.file.*;

public class Lab6 extends JFrame
{
    private JButton connectButton, disconnectButton, sendButton, fileTransferButton;
    private JTextField ipField, pNumField, msgField;
    private JRadioButton clientButton, serverButton, fTButton;
    private JTextArea  displayInformationArea;
    private ButtonGroup radioButtonGroup;
    
    private static final int BUFFERSIZE = 32;
    private File myFile;
    private String myFileName;
    private Path myPath;
    
    private byte[] sentByteBuffer = new byte[1000];
    private byte[] receivedByteBuffer = new byte[1000];
    byte[] data;
    
    private String serverInfoName;
    private String myPNum;
    int serverPort = 0;
    
    DatagramSocket s; 
    
    //Constructoer begins creates the GUI and action Listeners
    public Lab6 ( ) 
    {
     super("Rick Clapham - 821-490-125");
     
     setLayout (new GridLayout(6,2));

     connectButton = new JButton ("Connect");
     disconnectButton = new JButton ("Disconnect");
     fileTransferButton = new JButton ("File Transfer");
     sendButton = new JButton ("Send");
     ipField = new JTextField ("localhost");
     ipField.setEditable(false);
     pNumField = new JTextField ("40050");
     pNumField.setEditable(false);
     msgField = new JTextField ("Enter Message");
     msgField.setEditable(true);
     clientButton = new JRadioButton ("Initiate as Client");
     serverButton = new JRadioButton ("Initiate as Server");
     fTButton = new JRadioButton ("File Transfer Option");
     radioButtonGroup = new ButtonGroup();
     radioButtonGroup.add(clientButton);
     radioButtonGroup.add(serverButton);
     displayInformationArea = new JTextArea();
     displayInformationArea.setEditable(false);
    
     
     add(ipField);
     add(connectButton);
     add(pNumField);
     add(disconnectButton);
     add(msgField);
     add(sendButton);
     add(serverButton);
     add(clientButton);
     add(fTButton);
     add(fileTransferButton);
     add(new JScrollPane(displayInformationArea));
        
     RadioButtonHandler rButtonHandler = new RadioButtonHandler();
     JButtonHandler jButtonHandler = new JButtonHandler();
     
     connectButton.addActionListener(jButtonHandler);
     disconnectButton.addActionListener(jButtonHandler);
     sendButton.addActionListener(jButtonHandler);
     fileTransferButton.addActionListener(jButtonHandler);
    
     serverButton.addItemListener(rButtonHandler);
     clientButton.addItemListener(rButtonHandler);
     fTButton.addItemListener(rButtonHandler);
    } // end of the constructor GraphicalUserInterface  
        
    // Definition of the inner class RadioButtonHandler
    private class RadioButtonHandler implements ItemListener 
    {
        public RadioButtonHandler() {} // Constructor of RadioButtonHandler 
        
        public void itemStateChanged (ItemEvent event) 
        {
            if (event.getSource() == serverButton )
            {
                ipField.setEditable(true);
                pNumField.setEditable(true);
                displayInformationArea.setEditable(true);       
                displayInformationArea.setEditable(false);
            } 
            else if (event.getSource() == clientButton) 
            {
                ipField.setEditable(true);
                pNumField.setEditable(true);
                displayInformationArea.setEditable(true);
                displayInformationArea.setEditable(false);
            }
            else if (event.getSource() == fTButton) 
            {
                ipField.setEditable(true);
                pNumField.setEditable(true);
                displayInformationArea.setEditable(true);
                displayInformationArea.setEditable(false);
            }// end of if condition
        } // end of method itemStateChanged
    } // end of class definition RadioButtonHandler
    
    // Beginning of the inner class JButtonHandler
    private class JButtonHandler  implements ActionListener 
    { //beginning fo the class JButtonHandler
      public JButtonHandler (){} //CONSTRUCTOR 
      
      public void actionPerformed ( ActionEvent event) 
      { // beginning of actionPerformed
          if(event.getSource() == connectButton)
          {
             displayInformationArea.setEditable(true);
             connect();
             if(serverButton.isSelected() && fTButton.isSelected())
             {
               try{initiateFileServer();}catch(IOException f){}
             }
             else if(serverButton.isSelected() && !fTButton.isSelected())
             {
               Server myServer = new Server();
               try{myServer.main(serverPort);}catch(IOException e){}            
             }
             else if(clientButton.isSelected() && !fTButton.isSelected())
             {
                //serverInfoName
                //serverPort
                Client myClient = new Client();
                myClient.main(serverInfoName,serverPort);
             }
             displayInformationArea.setEditable(false);
          }
          else if(event.getSource() == disconnectButton)
          {
             displayInformationArea.setEditable(true);
             disconnect();
             displayInformationArea.setEditable(false);
          }
          else if(event.getSource() == sendButton)
          {
             displayInformationArea.setEditable(true);
             if(serverInfoName.equals(null) && (serverPort == 0))
                  displayInformationArea.setText("Not connected");
             displayInformationArea.setEditable(false);
          }
          else if(event.getSource() == fileTransferButton)
          {
             displayInformationArea.setEditable(true);
             if (clientButton.isSelected() && fTButton.isSelected())
             {
               chooseFile();
               toServerTCPFile();
             }
             displayInformationArea.setEditable(false);
          }
          else  
          {
            displayInformationArea.setEditable(true);
            displayInformationArea.setText("None of the Radio Buttons are selected");
            displayInformationArea.setEditable(false);
          } // end of else - if UDPButton is NOT selected and TCPButton is NOT selected
       } //end of the method actionPerformed
    } // end of the class JButtonHandler
      
    /**
    Simple method which simply reads the current given port number and IP and
    Records theinformation into 2 variables.
    */    
    public void connect(){
       serverInfoName = ipField.getText();
       myPNum = pNumField.getText();
       serverPort = Integer.parseInt(myPNum);
    }
    
    /**
    Simple Method which sets the given IP and port num to null
    */
    public void disconnect(){
       serverInfoName = null;
       myPNum = null;
       serverPort = 0;
    }
       
    /***
    * This is the code that will open the fileChooser and allow
    * the user to select a file and it will store the path and information           
    */   
    public void chooseFile(){
      JFileChooser fileChooser = new JFileChooser();
      int returnValue = fileChooser.showOpenDialog(null);
      if (returnValue == JFileChooser.APPROVE_OPTION) 
      {
        myFileName = fileChooser.getSelectedFile().getName();
        myPath = Paths.get(fileChooser.getSelectedFile().getAbsolutePath());
        displayInformationArea.setText("File Name: " + myFileName + "\nFile Path: " + myPath);
                        
        try
        {
           FileInputStream inputStream = new FileInputStream(myPath.toString());
           ByteArrayOutputStream baos = new ByteArrayOutputStream();
           int receivedMessageSize = 0;
               
           while(true) {
            receivedMessageSize = inputStream.read(sentByteBuffer);
            if( receivedMessageSize < 0 ) break;
            baos.write(sentByteBuffer,0,receivedMessageSize);
           }
           
           data = baos.toByteArray();                 
           baos.close();
           inputStream.close();
         }
         catch(FileNotFoundException ex) {displayInformationArea.setText("Unable to open file '" + myFileName + "'");}
         catch(IOException ex) {displayInformationArea.setText("Error reading file '" + myFileName + "'");} 
      }
    } 
   
    /*
    *This is the beginning of my method that will send a file to the Server
    */
    
    public void toServerTCPFile(){
      try
      {
        Socket socket = new Socket (serverInfoName, serverPort);
        InputStream  in = socket.getInputStream();
        OutputStream out = socket.getOutputStream ();
        //byte[] fileName=(((myFileName.substring(myFileName.lastIndexOf("\\")+1)).concat(":")).getBytes());
        byte[] buffer = data;
        //System.arraycopy(fileName, 0, buffer, 0, fileName.length);
        //System.arraycopy(data, 0, buffer, fileName.length, data.length);
        
        out.write(buffer);
               
        int totalBytesReceived = 0; // this is count of the total received bytes
        int bytesReceived = 0; // bytes received in the last receive method 
               
        while ( totalBytesReceived < buffer.length) 
        { // while begins
          if ((bytesReceived = in.read(receivedByteBuffer, totalBytesReceived, buffer.length - totalBytesReceived)) == -1 )
            throw new SocketException ("Connection closed prematurely...........\n");
            totalBytesReceived += bytesReceived;
        } // while loop ends here - comparing the totalBytesReceived with bytes sent out
   
        // Now display Bytes that are received back
        displayInformationArea.setText("The message from the server is recieved:\n\n" + new String(buffer).trim());
        socket.close();
               
      }
      catch(IOException e){displayInformationArea.setText("Error Sending data to server");}
    } 
   
   /**
   Creates an instance of my Fileserver which will freeze the gui until the file is recieved
   */
   public void initiateFileServer() throws IOException 
   {
      // main application begins here
      System.out.println ("\nTCP File Server starting ...\n");
      int serverListenPort = 40050;  // define the integer port number
      int receivedMessageSize=0; // size of the received message from Client
      byte [] byteBuffer = new byte [BUFFERSIZE];
      boolean loopBreaker = true; 
      
      ServerSocket serverSocket = new ServerSocket(serverListenPort);

      while (loopBreaker == true ) 
      { // Run forever - accepting and servicing connection
         Socket clientSock  = serverSocket.accept();  // Get the client connection                  
         System.out.println("\n....Handling Client at:....");
         System.out.println( clientSock.getInetAddress().getHostAddress() + "\n  on port number:\t" + clientSock.getPort());
         
         InputStream in = clientSock.getInputStream();
         OutputStream out = clientSock.getOutputStream();
         
         int totalBytesReceived = 0; 
         int bytesReceived = 0;
         
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         
         while (( receivedMessageSize = in.read(byteBuffer)) != -1){
                out.write(byteBuffer, 0, receivedMessageSize);
                baos.write(byteBuffer, 0, receivedMessageSize);
         }
         
         byte[] data = baos.toByteArray();
         baos.close();
         
         //String fileName = (data.toString().substring(0,data.toString().indexOf(":"))).concat(".bak");     

         File file = new File("./myFileTCP.txt.bak");        
         if (!file.exists()) {file.createNewFile();}
         FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);     
         bw.write(new String(data));
         bw.close();
         fw.close();
         clientSock.close();
         loopBreaker = false;  
      } // end of the for loop
   /******* this part can only be reached with Ctrl C ******/
   }
       
    public static void main (String [] args) 
    {
        Lab6 myGUIApp = new Lab6();
        myGUIApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myGUIApp.setSize(1000,600);
        myGUIApp.setVisible(true);
    }
}