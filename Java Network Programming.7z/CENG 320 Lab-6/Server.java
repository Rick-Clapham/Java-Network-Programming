/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/11/2015
*
* This is my Server class which is waits for a connection
* and upon recieivng a connection sets up a chat client between 
* the server and the client
*****/

import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.awt.*;
import javax.swing.*;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.*;
import java.nio.file.*;

public class Server 
{
   /**
   The main method which will initiate the server and upon reciving a connection
   it will create to threads to send and recieve betweenthe client and server
   @param myPort recieves a port number from the user
   */
	public static void main(int myPort) throws IOException 
   {
		final int port = myPort;
		System.out.println("Server Waiting For Connection On Port: "+port);
		ServerSocket myServerSocket = new ServerSocket(port);
		Socket myClientSocket = myServerSocket.accept();
		System.out.println("Recieved Connection From:\nIP:\t"+myClientSocket.getInetAddress()+"\nPort:\t"+myClientSocket.getPort());
		//create two threads to send and recieve from client
		ServerRecieveFromClient myReciever = new ServerRecieveFromClient(myClientSocket);
		Thread myThread1 = new Thread(myReciever);
		myThread1.start();
		ServerSendToClient mySender = new ServerSendToClient(myClientSocket);
		Thread myThread2 = new Thread(mySender);
		myThread2.start();
	}
}

/**
* This class sets up a server inorder to listen to messages from the client
* @param clientSocket recieves the socket to listen to from the main
*/   
class ServerRecieveFromClient implements Runnable
{
	Socket myClientSocket=null;
	BufferedReader myBufferedReader = null;
	
	public ServerRecieveFromClient(Socket clientSocket){
		this.myClientSocket = clientSocket;
	}//end constructor
	public void run() {
		try{
		myBufferedReader = new BufferedReader(new InputStreamReader(this.myClientSocket.getInputStream()));		
		
		String myMessage;
		while(true){
		while((myMessage = myBufferedReader.readLine())!= null){//assign message from client to messageString
			if(myMessage.equals("EXIT"))
			{
				break;//break to close socket if EXIT
			}
			System.out.println("Message From Client: " + myMessage);//print the message from client
			System.out.println("Please Enter A Response To The Client: ");
		}
		this.myClientSocket.close();
		System.exit(0);
	}
		
	}
	catch(Exception ex){System.out.println(ex.getMessage());}
	}
}

/**
* This class recieves the connected port and IP address and 
* will allow the user to respond to the client
* @param clientSocket recieves the socket from the main
*/   

class ServerSendToClient implements Runnable
{
	PrintWriter myPrintWriter;
	Socket myClientSock = null;
	
	public ServerSendToClient(Socket clientSock)
	{
		this.myClientSock = clientSock;
	}
   
	public void run() 
   {
		try
      {
		   myPrintWriter =new PrintWriter(new OutputStreamWriter(this.myClientSock.getOutputStream()));//get outputstream
		
		   while(true)
         {
			   String myMessage = null;
			   BufferedReader input = new BufferedReader(new InputStreamReader(System.in));//get userinput
			
			   myMessage = input.readLine();//get message to send to client
			
			   myPrintWriter.println(myMessage);//send message to client with PrintWriter
			   myPrintWriter.flush();//flush the PrintWriter
			   System.out.println("Please enter something to send back to client..");
		   }//end while
		}
		catch(Exception ex){System.out.println(ex.getMessage());}	
	}//end run
}