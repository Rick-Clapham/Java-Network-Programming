/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/11/2015
*
* Simple Book object the server class uses it to create a local database
*****/

import java.io.*;
import java.net.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class Book
{
   private String title;
   private String author;
   private String subject;
   private int quantity;
   private double price;
   
   public Book()
   {
      title = "";
      author = "";
      subject = "";
      quantity = 0;
      price = 0;
   }
   
   public Book(String salt1, String salt2, String salt3, int salt4, double salt5)
   {
      title = salt1;
      author = salt2;
      subject = salt3;
      quantity = salt4;
      price = salt5;
   }
   
   public void setTitle(String i){title = i;}
   public void setAuthor(String i){author = i;}
   public void setSubject(String i){subject = i;}
   public void setQuantity(int i){quantity = i;}
   public void setPrice(double i){price = i;}
   
   public String getTitle(){return title;}
   public String getAuthor(){return author;}
   public String getSubject(){return subject;}
   public int getQuantity(){return quantity;}
   public double getPrice(){return price;}
   
   public String toString(){return "Book Title:\t"+title+"\tAuthor:\t"+author+"\tSubject:\t"+subject+"\tQuantity:\t"+quantity+"\tPrice:\t"+price;}
}