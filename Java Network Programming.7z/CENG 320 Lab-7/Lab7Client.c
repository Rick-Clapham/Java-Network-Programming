//Name: Richard Clapham
//Student #: 821-490-125
//Date: 11/23/2015
// Lab7 Client the client recieves all the information provided by the user and sends it to the server
// The client does no error checking so please ensure that you enter in values when th client prompts you to
// The client does have full functionality though it will connect to the sever and return the correct information

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <stdlib.h> 
#include <ctype.h>

void error(char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    int sockfd, portno, n;
    int myLoop = 1;
    int myChoice = 0;

    struct sockaddr_in serv_addr;
    struct hostent *server;

    char buffer[1000];
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
        
    //My code to send and reive should go here 
	while(myLoop == 1){
		char myBuffer[50];
		printf("\nMain Menu\n");
		printf("-----------------------------------\n");
		printf("1)\tDisplay All\n");
		printf("2)\tAdd\n");
		printf("3)\tSearch\n");
		printf("4)\tUpdate\n");
		printf("5)\tQuit\n");
		printf("\nPlease Enter Your Choice:\t");
		fgets(myBuffer, 50, stdin);
		strtok(myBuffer, "\n");
		myChoice = atoi(myBuffer);
		printf("Your Choice is: %d\n", myChoice);		

		if(myChoice == 1)
		{
			//Sends message to Server
			bzero(buffer,1000);
			buffer[0] = '1';
			strcat(buffer, ":");

			printf("\nMessage is:\n");
			printf(buffer);
			printf("\n\n");

			n = write(sockfd,buffer,strlen(buffer));
			if (n < 0) 
				error("ERROR writing to socket");
			
		}
		if(myChoice == 2)
		{
			char buffer2[256];
			bzero(buffer,1000);
			buffer[0] = '2';
			strcat(buffer, ":");
			printf("\nPlease enter the Author Name: ");
			fgets(buffer2,255,stdin);
			strtok(buffer, "\n");
			strtok(buffer2, "\n");
			strcat(buffer2, ":");
			strcat(buffer, buffer2);
			bzero(buffer2,256);
			printf("Please enter the Book Title: ");
			fgets(buffer2,255,stdin);
			strtok(buffer, "\n");
			strtok(buffer2, "\n");
			strcat(buffer2, ":");
			strcat(buffer, buffer2);
			bzero(buffer2,256);
			printf("Please enter the Subject Area: ");
			fgets(buffer2,255,stdin);
			strtok(buffer, "\n");
			strtok(buffer2, "\n");
			strcat(buffer2, ":");
			strcat(buffer, buffer2);
			bzero(buffer2,256);
			printf("Please enter the Quantity: ");
			fgets(buffer2,255,stdin);
			strtok(buffer, "\n");
			strtok(buffer2, "\n");
			strcat(buffer2, ":");
			strcat(buffer, buffer2);
			bzero(buffer2,256);
			printf("Please enter the Price: ");
			fgets(buffer2,255,stdin);
			strtok(buffer, "\n");
			strtok(buffer2, "\n");
			strcat(buffer2, ":");
			strcat(buffer, buffer2);
			strtok(buffer, "\n");

			printf("\nMessage is:\n");
			printf(buffer);
			printf("\n\n");
			
			n = write(sockfd,buffer,strlen(buffer));
			if (n < 0) 
				error("ERROR writing to socket");
			
		}
		if(myChoice == 3)
		{
			int myChoice2 = 0;
			bzero(myBuffer,50);
			printf("\n1)\tSearch by Author Name\n");
			printf("2)\tSeatch by Subject Area\n");
			printf("3)\tSearch by Book Title\n");
			printf("\nPlease Enter Your Choice:\t");
			fgets(myBuffer, 50, stdin);
			strtok(myBuffer, "\n");
			myChoice2 = atoi(myBuffer);
			printf("Your Choice is: %d\n", myChoice2);
			
			if(myChoice2 == 1)
			{
				char buffer2[256];
				bzero(buffer,1000);
				buffer[0] = '3';
				strcat(buffer, ":");
				bzero(buffer2,256);
				printf("\nPlease enter the Author Name: ");
				fgets(buffer2,255,stdin);
				strtok(buffer, "\n");
				strtok(buffer2, "\n");
				strcat(buffer, buffer2);
				strcat(buffer, ":");

				printf("\nMessage is:\n");
				printf(buffer);
				printf("\n\n");
				
				n = write(sockfd,buffer,strlen(buffer));
				if (n < 0) 
					error("ERROR writing to socket");
	 
			}
			if(myChoice2 == 2)
			{
				char buffer2[256];
				bzero(buffer,1000);
				buffer[0] = '4';
				strcat(buffer, ":");
				bzero(buffer2,256);
				printf("\nPlease enter the Subject Area: ");
				fgets(buffer2,255,stdin);
				strtok(buffer, "\n");
				strtok(buffer2, "\n");
				strcat(buffer, buffer2);
				strcat(buffer, ":");

				printf("\nMessage is:\n");
				printf(buffer);
				printf("\n\n");
				
				n = write(sockfd,buffer,strlen(buffer));
				if (n < 0) 
					error("ERROR writing to socket");
	 
			}
			if(myChoice2 == 3)
			{
				char buffer2[256];
				bzero(buffer,1000);
				buffer[0] = '5';
				strcat(buffer, ":");
				bzero(buffer2,256);
				printf("\nPlease enter the Book Title: ");
				fgets(buffer2,255,stdin);
				strtok(buffer, "\n");
				strtok(buffer2, "\n");
				strcat(buffer, buffer2);
				strcat(buffer, ":");

				printf("\nMessage is:\n");
				printf(buffer);
				printf("\n\n");
				
				n = write(sockfd,buffer,strlen(buffer));
				if (n < 0) 
					error("ERROR writing to socket");
	 
			}
		}
		if(myChoice == 4)
		{
			int myChoice2 = 0;
			bzero(myBuffer,50);
			printf("\n1)\tUpdate the Price\n");
			printf("2)\tUpdate the Quantity\n");
			printf("\nPlease Enter Your Choice:\t");
			fgets(myBuffer, 50, stdin);
			strtok(myBuffer, "\n");
			myChoice2 = atoi(myBuffer);
			printf("Your Choice is: %d\n", myChoice2);

			if(myChoice2 == 1)
			{
				char buffer2[256];
				bzero(buffer,1000);
				buffer[0] = '6';
				strcat(buffer, ":");
				bzero(buffer2,256);
				printf("\nPlease enter the Book Title: ");
				fgets(buffer2,255,stdin);
				strtok(buffer, "\n");
				strtok(buffer2, "\n");
				strcat(buffer2, ":");
				strcat(buffer, buffer2);

				bzero(buffer2,256);
				printf("Please enter the Price: ");
				fgets(buffer2,255,stdin);
				strtok(buffer, "\n");
				strtok(buffer2, "\n");
				strcat(buffer, buffer2);
				strcat(buffer, ":");
				
				printf("\nMessage is:\n");
				printf(buffer);
				printf("\n\n");

				n = write(sockfd,buffer,strlen(buffer));
				if (n < 0) 
					error("ERROR writing to socket");
	 
			}
			if(myChoice2 == 2)
			{
				char buffer2[256];
				bzero(buffer,1000);
				buffer[0] = '7';
				strcat(buffer, ":");
				bzero(buffer2,256);
				printf("\nPlease enter the Book Title: ");
				fgets(buffer2,255,stdin);
				strtok(buffer, "\n");
				strtok(buffer2, "\n");
				strcat(buffer2, ":");
				strcat(buffer, buffer2);

				bzero(buffer2,256);
				printf("Please enter the Quantity: ");
				fgets(buffer2,255,stdin);
				strtok(buffer, "\n");
				strtok(buffer2, "\n");
				strcat(buffer, buffer2);
				strcat(buffer, ":");

				printf("\nMessage is:\n");
				printf(buffer);
				printf("\n\n");
				
				n = write(sockfd,buffer,strlen(buffer));
				if (n < 0) 
					error("ERROR writing to socket");
			}
		}
		if(myChoice == 5)
		{
			bzero(buffer,1000);
			buffer[0] = 'E';
	
			printf("\nMessage is:\n");
			printf(buffer);
			printf("\n\n");
		
			n = write(sockfd,buffer,strlen(buffer));
			if (n < 0) 
				error("ERROR writing to socket");
			myLoop = 0;
		}

		//Recieves message back from server
		if(myChoice == 1 || myChoice == 2 || myChoice == 3 || myChoice == 4 || myChoice == 5){
			bzero(buffer,1000);
			n = read(sockfd,buffer,1000);
			if (n < 0) 
				error("ERROR reading from socket");
			printf("%s\n",buffer);
		}
		else{
		printf("\nPlease Enter A Correct Command\n");
		}
	}
	return 0;
	/*printf("Please enter the message: ");
    bzero(buffer,1000);
    fgets(buffer,255,stdin);
    n = write(sockfd,buffer,strlen(buffer));
    if (n < 0) 
         error("ERROR writing to socket");
	 
    bzero(buffer,1000);
    n = read(sockfd,buffer,255);
    if (n < 0) 
         error("ERROR reading from socket");
    printf("%s\n",buffer);
    return 0;*/
}
