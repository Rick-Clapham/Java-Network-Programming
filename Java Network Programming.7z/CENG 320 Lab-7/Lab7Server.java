/**
* Name: Rick Clapham
* Student #: 821-490-125
* Student ID: n00663650
* Last Modified: 10/11/2015
*
* This program will create a server for Lab7 it will diaplay the ip and port number it is listening on when it starts
* The server will then listen for the client. Based on the string the client sends it will recieve the strign and parse the data
*depending on myString at index 0 it will perform different methods and return the information.

* The server does not connect to another remote mySQL database it simply uses a local arraylist of books hoever
* It should be able to function with a reote database if it was created and simply parsedthe given data into
* a query created by me.
*****/


import java.io.*;
import java.net.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.io.FileOutputStream; 
import java.io.FileInputStream;

public class Lab7Server
{ // beginning of the class Lab4Server 
   private static final int BUFFERSIZE = 32;
   
   public static void main (String [] args ) throws IOException 
   {
      ArrayList<Book> myBooks = new ArrayList<Book>();
      myBooks.add(new Book("Harry Potter 1", "J.K. Rowling", "Fantasy", 12, 12.99));
      myBooks.add(new Book("The Lord of the Rings", "J.R.R. Tolkien", "Fantasy", 150, 30.00));
      myBooks.add(new Book("Harry Potter 2", "J.K. Rowling", "Fantasy", 12, 18.99));
      myBooks.add(new Book("Java", "Guy", "Syntax", 17, 129.99));
      myBooks.add(new Book("Book of Salt", "Rick", "Salt", 500, 1.99));
      boolean myServerLoop = true;
      // main application begins here
      System.out.println ("\nTCP Server starting ...\n");
      int serverListenPort = 40005;  // define the integer port number
      InetAddress serverIP = InetAddress.getLocalHost();
      System.out.println("IP Address is:\t" + serverIP.getHostAddress());
      System.out.println("Port Number is:\t" + serverListenPort);
      
      int receivedMessageSize=0; // size of the received message from Client
      byte [] byteBuffer = new byte [BUFFERSIZE];
      String myData = " ";
      
      ServerSocket serverSocket = new ServerSocket(serverListenPort);

      while(myServerLoop == true) 
      { // Run forever - accepting and servicing connection
         Socket clientSock  = serverSocket.accept();  // Get the client connection                  
         System.out.println("\n....Handling Client at:....");
         System.out.println(clientSock.getInetAddress().getHostAddress() + "\n  on port number:\t" + clientSock.getPort());
         
         InputStream in = clientSock.getInputStream();
         OutputStream out = clientSock.getOutputStream();
         
         
         while (( receivedMessageSize = in.read(byteBuffer)) != -1){
                //out.write(byteBuffer, 0, receivedMessageSize);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
                baos.write(byteBuffer, 0, receivedMessageSize);

		byte[] data = baos.toByteArray();
         	myData = new String(data).trim();
	 	System.out.println(myData);
		baos.close();

		if(myData.charAt(0) == '1')
        	{
			System.out.println("Display All");
			String myString = "";
         int count2 = 0;
			for(int count = 0; count < myBooks.size(); count++)
			{
				System.out.println(myBooks.get(count).toString());
				myString = myString + "\n" + myBooks.get(count).toString();
            count2++;
				//out.write(myBooks.get(count).toString().getBytes());
			}
         if(count2 > 0){
			   out.write(myString.getBytes());
         }
         else{
			   out.write("There is no Books in the Database\n".getBytes());
         } 
      }
      else
	 	if(myData.charAt(0) == '2')
      {
      try{
			System.out.println("Add");
			Scanner myScanner = new Scanner(myData);
			while(myScanner.hasNext())
			{
				myScanner.useDelimiter(":");
				String myChoice = myScanner.next();
				String myAuthor = myScanner.next();
				String myBook = myScanner.next();
				String mySubject  = myScanner.next();
				String myQuantity = myScanner.next();
				String myPrice = myScanner.next();
				System.out.println("Choice: " + myChoice);				
				System.out.println("Author: " + myAuthor);
				System.out.println("Book Title: " + myBook);
				System.out.println("Subject: " + mySubject);
				System.out.println("Quantity: " + myQuantity);
				System.out.println("Price: " + myPrice);
				int myQuantity2 = Integer.parseInt(myQuantity);
				double myPrice2 = Double.parseDouble(myPrice);
				myBooks.add(new Book(myBook, myAuthor, mySubject, myQuantity2, myPrice2));
				Book myTemp = new Book(myBook, myAuthor, mySubject, myQuantity2, myPrice2);
				out.write(myTemp.toString().getBytes());
			}
         }catch(Exception e){out.write("Data Entered Was Not Valid".getBytes());}
      }
	 	if(myData.charAt(0) == '3')
      {
         try{
			System.out.println("Search by Author");
			Scanner myScanner = new Scanner(myData);
			while(myScanner.hasNext())
			{
				myScanner.useDelimiter(":");
				String myChoice = myScanner.next();
				String myAuthor = myScanner.next();
				System.out.println("Choice: " + myChoice);				
				System.out.println("Author: " + myAuthor);
				String myString = "";
            	int count2 = 0;
				for(int count = 0; count < myBooks.size(); count++)
				{
					if(myBooks.get(count).getAuthor().toLowerCase().equals(myAuthor.toLowerCase()))
					{
						myString = myString + "\n" + myBooks.get(count).toString();
						System.out.println(myBooks.get(count).toString());
                  count2++;
						//out.write(myBooks.get(count).toString().getBytes());
					}
				}
				if(count2 > 0){
			      out.write(myString.getBytes());
            }
            else{
			      out.write("There is no Books by that Author\n".getBytes());
            } 
			}
         }catch(Exception e){out.write("Data Entered Was Not Valid".getBytes());}
      }
	 	if(myData.charAt(0) == '4')
         	{
            try{
			System.out.println("Search by Subject");
			Scanner myScanner = new Scanner(myData);
			while(myScanner.hasNext())
			{
				myScanner.useDelimiter(":");
				String myChoice = myScanner.next();
				String mySubject = myScanner.next();
				System.out.println("Choice: " + myChoice);				
				System.out.println("Subject: " + mySubject);
				String myString = "";
            int count2 = 0;
				for(int count = 0; count < myBooks.size(); count++)
				{
					if(myBooks.get(count).getSubject().toLowerCase().equals(mySubject.toLowerCase()))
					{
						myString = myString + "\n" + myBooks.get(count).toString();
						System.out.println(myBooks.get(count).toString());
                  count2++;
						//out.write(myBooks.get(count).toString().getBytes());
					}
				}
				if(count2 > 0){
			      out.write(myString.getBytes());
            }
            else{
			      out.write("There is no Books by that Subject\n".getBytes());
            } 
			}
         }catch(Exception e){out.write("Data Entered Was Not Valid".getBytes());}
      }
	 	if(myData.charAt(0) == '5')
      {
         try{
			System.out.println("Search by Book Title");
			Scanner myScanner = new Scanner(myData);
			while(myScanner.hasNext())
			{
				myScanner.useDelimiter(":");
				String myChoice = myScanner.next();
				String myBook = myScanner.next();
				System.out.println("Choice: " + myChoice);				
				System.out.println("Book Title: " + myBook);
				String myString = "";
            int count2 = 0;
				for(int count = 0; count < myBooks.size(); count++)
				{
					if(myBooks.get(count).getTitle().toLowerCase().equals(myBook.toLowerCase()))
					{
						myString = myString + "\n" + myBooks.get(count).toString();
						System.out.println(myBooks.get(count).toString());
                  count2++;
						//out.write(myBooks.get(count).toString().getBytes());
					}
				}
				if(count2 > 0){
			      out.write(myString.getBytes());
            }
            else{
			      out.write("There is no Books by that Title\n".getBytes());
            } 
			}
         }catch(Exception e){out.write("Data Entered Was Not Valid".getBytes());}
      }
	 	if(myData.charAt(0) == '6')
      {
         try{
			System.out.println("Update Price");
			Scanner myScanner = new Scanner(myData);
			while(myScanner.hasNext())
			{
				myScanner.useDelimiter(":");
				String myChoice = myScanner.next();
				String myBook = myScanner.next();
				String myPrice = myScanner.next();
				System.out.println("Choice: " + myChoice);				
				System.out.println("Book Title: " + myBook);
				System.out.println("Price: " + myPrice);
				double myPrice2 = Double.parseDouble(myPrice);
				String myString = "";
            int count2 = 0;
				for(int count = 0; count < myBooks.size(); count++)
				{
					if(myBooks.get(count).getTitle().toLowerCase().equals(myBook.toLowerCase()))
					{
						myString = myString + "\n" + myBooks.get(count).toString();
						System.out.println(myBooks.get(count).toString());
						myBooks.get(count).setPrice(myPrice2);
						myString = myString + "\n" + myBooks.get(count).toString();
						System.out.println(myBooks.get(count).toString());
                  count2++;
						//out.write(myBooks.get(count).toString().getBytes());
					}
				}
				if(count2 > 0){
			      out.write(myString.getBytes());
            }
            else{
			      out.write("There is no Books by that title the no price was updated\n".getBytes());
            }	
			}
         }catch(Exception e){out.write("Data Entered Was Not Valid".getBytes());}
      }
	 	if(myData.charAt(0) == '7')
         	{
            try{
			System.out.println("Update Quantity");
			Scanner myScanner = new Scanner(myData);
			while(myScanner.hasNext())
			{
				myScanner.useDelimiter(":");
				String myChoice = myScanner.next();
				String myBook = myScanner.next();
				String myQuantity = myScanner.next();
				System.out.println("Choice: " + myChoice);				
				System.out.println("Book Title: " + myBook);
				System.out.println("Quantity: " + myQuantity);
				int myQuantity2 = Integer.parseInt(myQuantity);
				String myString = "";
            int count2 = 0;
				for(int count = 0; count < myBooks.size(); count++)
				{
					if(myBooks.get(count).getTitle().toLowerCase().equals(myBook.toLowerCase()))
					{
						myString = myString + "\n" + myBooks.get(count).toString();
						System.out.println(myBooks.get(count).toString());
						myBooks.get(count).setQuantity(myQuantity2);
						myString = myString + "\n" + myBooks.get(count).toString();
						System.out.println(myBooks.get(count).toString());
                  count2++;
						//out.write(myBooks.get(count).toString().getBytes());
					}
				}
				if(count2 > 0){
			      out.write(myString.getBytes());
            }
            else{
			      out.write("There is no Books by that title the no quantity was updated\n".getBytes());
            } 	
			}
         }catch(Exception e){out.write("Data Entered Was Not Valid".getBytes());}
      }
      if(myData.charAt(0) == 'E')
      {
			System.out.println("Server Shutting Down");
			out.write("Server Shutting Down".getBytes());
            		myServerLoop = false;
      }
         }

	 clientSock.close();
      } // end of the for loop
   /******* this part can only be reached with Ctrl C ******/
   } // main application ends here
} // Lab4Server
